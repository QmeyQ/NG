/**
 * te/user.js - 用户系统云函数 handler(AGC Node.js)
 *
 * 请求(经 Worker 代理 data): { t: "reg"|"user"|"bag"|"set"|"buy"|"del", d: {...} }
 * (管理后台已抽离为独立 mag 函数)
 *
 * 存储(CloudDB NG 对象类型, 经 db.js → Worker → cloudb 函数, 多实例共享):
 *   id(主键)=userid  name  flag  bag(JSON字符串)  dollar(Integer)
 *   head  etc(ctime 毫秒字符串)
 *
 * 密匙体系(见 code.js):
 *   - rawKey = code.key(userid): 确定性密匙
 *   - 客户端持有的 key = code.enc(rawKey): 加密密匙(每次注册随机不同)
 *   - 注册时 encKey 存入行 secret 字段; 认证: secret 直比(无 secret 老行回退 code.dec)
 *
 * 规则:
 *   - 注册: 初始 dollar=1, 默认头像 x1
 *   - 改名: 消耗 1 金币/次
 *   - 设置头像: 校验背包数量, 消耗 1 个
 *   - 购买: 消耗 1 金币/个, 背包 +1; 商品为 dollar 时金币 +5(不消耗金币)
 *   - 删除: 删除整行
 *
 * 错误码: 0成功 1用户不存在 2认证失败 3背包数量不足 4金币不足 5参数错误 6已注册
 */
const code = require('./code');
// db(内嵌 CloudDB SDK)延迟到 handler 内 require: 云端加载失败时可将具体错误返回客户端而非 500
let db = null;

const DEFAULT_HEAD = 'head/0101.png';
const DEFAULT_FLAG = '美好的一天开始喽！';
/** 顺序 id 计数器行(etc 存当前值), 管理后台列表过滤该行 */
const SEQ_ROW = '_seq';

// 代码版本(每次部署自增): 客户端响应 v 字段可核对云端实际运行的版本, 部署问题定位后删除
const CODE_V = 'v1022a';

function out(code, extra) {
    return Object.assign({ code: code, v: CODE_V }, extra || {});
}

/** NG 行 → 客户端 user 对象(含 bag 解析) */
function rowToUser(row) {
    let bag = {};
    try { bag = JSON.parse(row.bag || '{}'); } catch (e) { }
    return {
        userid: row.id,
        name: row.name || '',
        flag: row.flag || '',
        head: row.head || '',
        dollar: row.dollar || 0,
        bag: bag,
        ctime: parseInt(row.etc || '0', 10) || undefined
    };
}

/** 认证: 注册时下发的 secret(=encKey) 直比; 老用户行无 secret 回退 dec 解算验证 */
function authOk(row, key, id) {
    if (row.secret) return String(key) === String(row.secret);
    return code.dec(key) === code.key(id);
}

/** NG 行 → bag 对象 */
function rowBag(row) {
    try { return JSON.parse(row.bag || '{}'); } catch (e) { return {}; }
}

/** Dollar 货币商品判定(与前端 slecet.isDollarItem 同语义): 金币 +5 不消耗金币 */
function isDollarItem(p) {
    return /(^|\/)dollar\.png$/i.test(String(p || ''));
}

// ==================== handler ====================

let myHandler = async function (event, context, callback, logger) {
    let req;
    try {
        req = event.body ? (typeof event.body === 'string' ? JSON.parse(event.body) : event.body) : event;
    } catch (e) {
        callback(out(5, { msg: '请求解析失败' }));
        return;
    }

    const t = req.t;
    const d = req.d || {};

    try {
        if (!db) db = require('./db');
    } catch (e) {
        // 诊断: 扫描代码目录结构随错误返回(定位云端解压问题), 问题解决后删除
        let tree = '';
        try {
            const fs = require('fs');
            const path = require('path');
            const base = path.dirname(__filename);
            const nm = path.join(base, 'node_modules');
            if (fs.existsSync(nm)) {
                tree += ' | nm=[' + fs.readdirSync(nm).slice(0, 30).join(',') + ']';
                const hwDb = path.join(nm, '@hw-agconnect', 'database-server', 'dist', 'index.js');
                tree += ' | dbServer存在=' + fs.existsSync(hwDb);
            } else tree += ' | node_modules不存在';
            tree += ' | 根=' + fs.readdirSync(base).slice(0, 30).join(',');
        } catch (e2) { tree = ' | 扫描失败:' + e2.message; }
        callback(out(5, { msg: '模块加载失败 v' + process.version + ': ' + String(e && e.message || e).slice(0, 150) + tree }));
        return;
    }

        try {
            switch (t) {

            // ---- 轻量身份验证(Worker /token 换直连 token 前置校验, 不回用户数据) ----
            case 'agt': {
                if (!d.userid || !d.key) { callback(out(5, { msg: '缺少 userid/key' })); return; }
                const row = await db.dbGet(String(d.userid));
                if (!db.dbOk) { callback(out(5, { msg: '存储访问失败: ' + (db.dbErr() || '未知') })); return; }
                if (!row) { callback(out(1, { msg: '用户不存在' })); return; }
                if (!authOk(row, d.key, String(d.userid))) { callback(out(2, { msg: '密匙错误' })); return; }
                callback(out(0, {}));
                return;
            }

            // ---- 注册 ----
            case 'reg': {
                // 旧客户端兼容: 显式传 userid 仍按传入 id 注册
                if (d.userid) {
                    const id0 = String(d.userid);
                    const exists0 = await db.dbGet(id0);
                    if (!db.dbOk) { callback(out(5, { msg: '存储访问失败: ' + (db.dbErr() || '未知') })); return; }
                    if (exists0) { callback(out(6, { msg: '该用户已注册' })); return; }
                    const bag0 = {};
                    bag0[DEFAULT_HEAD] = 1;
                    const user0 = {
                        userid: id0,
                        name: d.name || ('玩家' + id0.slice(-4)),
                        flag: d.flag || DEFAULT_FLAG,
                        head: DEFAULT_HEAD,
                        dollar: 1,
                        bag: bag0
                    };
                    const encKey0 = code.enc(code.key(id0));
                    if (!encKey0) { callback(out(5, { msg: '密匙生成失败' })); return; }
                    const ok0 = await db.dbPut(id0, {
                        name: user0.name,
                        flag: user0.flag,
                        head: user0.head,
                        dollar: user0.dollar,
                        bag: JSON.stringify(bag0),
                        secret: encKey0,
                        etc: String(Date.now())
                    });
                    if (!ok0) { callback(out(5, { msg: '存储写入失败: ' + (db.dbErr() || '未知') })); return; }
                    if (logger) logger.info('reg user: ' + id0);
                    callback(out(0, { key: encKey0, user: user0 }));
                    return;
                }

                // 顺序 id 分配: _seq 计数器行(etc 存当前值), 从 1000 起(最短 4 位纯数字)
                // 撞号(并发/历史残留)时推进计数重试
                for (let attempt = 0; attempt < 8; attempt++) {
                    const seqRow = await db.dbGet(SEQ_ROW);
                    if (!db.dbOk) { callback(out(5, { msg: '存储访问失败: ' + (db.dbErr() || '未知') })); return; }
                    let n = parseInt(seqRow && seqRow.etc, 10);
                    if (!isFinite(n) || n < 1000) n = 1000;
                    const id = String(n);
                    const exists = await db.dbGet(id);
                    if (!db.dbOk) { callback(out(5, { msg: '存储访问失败: ' + (db.dbErr() || '未知') })); return; }
                    if (exists) {
                        await db.dbPut(SEQ_ROW, { etc: String(n + 1) });
                        continue;
                    }
                    const bag = {};
                    bag[DEFAULT_HEAD] = 1;
                    const user = {
                        userid: id,
                        name: d.name || ('玩家' + id.slice(-4)),
                        flag: d.flag || DEFAULT_FLAG,
                        head: DEFAULT_HEAD,
                        dollar: 1,
                        bag: bag
                    };
                    const encKey = code.enc(code.key(id));
                    if (!encKey) { callback(out(5, { msg: '密匙生成失败' })); return; }
                    const ok = await db.dbPut(id, {
                        name: user.name,
                        flag: user.flag,
                        head: user.head,
                        dollar: user.dollar,
                        bag: JSON.stringify(bag),
                        secret: encKey,
                        etc: String(Date.now())
                    });
                    if (!ok) { callback(out(5, { msg: '存储写入失败: ' + (db.dbErr() || '未知') })); return; }
                    await db.dbPut(SEQ_ROW, { etc: String(n + 1) });
                    if (logger) logger.info('reg user: ' + id);
                    callback(out(0, { key: encKey, user: user }));
                    return;
                }
                callback(out(5, { msg: 'id 分配失败(多次撞号)' }));
                return;
            }

            // ---- 更新昵称/签名(改名消耗 1 金币) ----
            case 'user': {
                if (!d.userid || !d.key) { callback(out(5)); return; }
                const id = String(d.userid);
                const row = await db.dbGet(id);
                if (!db.dbOk) { callback(out(5, { msg: '存储访问失败: ' + (db.dbErr() || '未知') })); return; }
                if (!row) { callback(out(1)); return; }
                if (!authOk(row, d.key, id)) { callback(out(2)); return; }
                const fields = {};
                if (d.name !== undefined && d.name !== null && String(d.name) !== row.name) {
                    if ((row.dollar || 0) < 1) { callback(out(4, { msg: '改名需要 1 金币' })); return; }
                    fields.dollar = (row.dollar || 0) - 1;
                    fields.name = String(d.name);
                }
                if (d.flag !== undefined && d.flag !== null) fields.flag = String(d.flag);
                if (!Object.keys(fields).length) { callback(out(0, { user: rowToUser(row) })); return; }
                const ok = await db.dbPut(id, fields);
                if (!ok) { callback(out(5, { msg: '存储写入失败: ' + (db.dbErr() || '未知') })); return; }
                const nrow = Object.assign({}, row, fields);
                callback(out(0, { user: rowToUser(nrow) }));
                return;
            }

            // ---- 背包查询 ----
            case 'bag': {
                if (!d.userid || !d.key) { callback(out(5)); return; }
                const id = String(d.userid);
                const row = await db.dbGet(id);
                if (!db.dbOk) { callback(out(5, { msg: '存储访问失败: ' + (db.dbErr() || '未知') })); return; }
                if (!row) { callback(out(1)); return; }
                if (!authOk(row, d.key, id)) { callback(out(2)); return; }
                callback(out(0, { bag: rowBag(row), dollar: row.dollar || 0 }));
                return;
            }

            // ---- 设置头像(校验背包数量, 消耗 1) ----
            case 'set': {
                if (!d.userid || !d.key) { callback(out(5)); return; }
                if (!d.head) { callback(out(5, { msg: '缺少 head' })); return; }
                const id = String(d.userid);
                const row = await db.dbGet(id);
                if (!db.dbOk) { callback(out(5, { msg: '存储访问失败: ' + (db.dbErr() || '未知') })); return; }
                if (!row) { callback(out(1)); return; }
                if (!authOk(row, d.key, id)) { callback(out(2)); return; }
                const bag = rowBag(row);
                const n = bag[d.head] || 0;
                if (n < 1) { callback(out(3, { msg: '背包中该头像数量不足' })); return; }
                if (n === 1) delete bag[d.head]; else bag[d.head] = n - 1;
                const ok = await db.dbPut(id, { bag: JSON.stringify(bag), head: d.head });
                if (!ok) { callback(out(5, { msg: '存储写入失败: ' + (db.dbErr() || '未知') })); return; }
                if (logger) logger.info('set head: ' + d.userid + ' -> ' + d.head);
                const nrow = Object.assign({}, row, { bag: JSON.stringify(bag), head: d.head });
                callback(out(0, { user: rowToUser(nrow) }));
                return;
            }

            // ---- 购买(消耗 1 金币/个, 背包 +1; dollar 商品: 金币 +5, 不消耗金币) ----
            case 'buy': {
                if (!d.userid || !d.key) { callback(out(5)); return; }
                if (!d.item) { callback(out(5, { msg: '缺少 item' })); return; }
                const id = String(d.userid);
                const row = await db.dbGet(id);
                if (!db.dbOk) { callback(out(5, { msg: '存储访问失败: ' + (db.dbErr() || '未知') })); return; }
                if (!row) { callback(out(1)); return; }
                if (!authOk(row, d.key, id)) { callback(out(2)); return; }
                const bag = rowBag(row);
                const fields = {};
                if (isDollarItem(d.item)) {
                    fields.dollar = (row.dollar || 0) + 5;
                    if (logger) logger.info('buy dollar: ' + d.userid + ' +5');
                } else {
                    if ((row.dollar || 0) < 1) { callback(out(4, { msg: '金币不足' })); return; }
                    fields.dollar = (row.dollar || 0) - 1;
                    bag[d.item] = (bag[d.item] || 0) + 1;
                    fields.bag = JSON.stringify(bag);
                    if (logger) logger.info('buy: ' + d.userid + ' -> ' + d.item);
                }
                const ok = await db.dbPut(id, fields);
                if (!ok) { callback(out(5, { msg: '存储写入失败: ' + (db.dbErr() || '未知') })); return; }
                const nrow = Object.assign({}, row, fields);
                callback(out(0, { user: rowToUser(nrow) }));
                return;
            }

            // ---- 注销(删除整行) ----
            case 'del': {
                if (!d.userid || !d.key) { callback(out(5)); return; }
                const id = String(d.userid);
                const row = await db.dbGet(id);
                if (!db.dbOk) { callback(out(5, { msg: '存储访问失败: ' + (db.dbErr() || '未知') })); return; }
                if (!row) { callback(out(1)); return; }
                if (!authOk(row, d.key, id)) { callback(out(2)); return; }
                const ok = await db.dbDel(id);
                if (!ok) { callback(out(5, { msg: '存储删除失败' })); return; }
                if (logger) logger.info('del user: ' + d.userid);
                callback(out(0));
                return;
            }

            default:
                callback(out(5, { msg: '未知 t: ' + t }));
        }
    } catch (e) {
        if (logger) logger.error('te/user error: ' + (e && e.stack));
        callback(out(5, { msg: '服务器内部错误 v' + process.version + ': ' + String(e && e.message || e).slice(0, 300) }));
    }
};

module.exports.myHandler = myHandler;
