/**
 * code.js - 密匙计算与加密(AGC Node.js)
 *
 * key(userid): userid -> 确定性密匙(32 hex 字符, 加盐 sha256 前 16 字节)
 *              服务器可由 userid 直接解算出密匙(即用户目录名), 从而主动定位/查询用户
 *
 * enc(rawKey): 密匙加密, 每次输出随机(hex 字符串):
 *   - 头字节 = '@'(0x40) ^ 随机字节(1~255)
 *   - 每个明文字节先与随机数异或, 再与前一个输出链式相加
 *   - 每明文字节输出一个 16 位 word: 低 6 位编码位置 j, 高 10 位为链式混合值
 *     -> 即使明文所有字节相同, 输出 word 也逐个不同(位置编码构造保证)
 *   - 头字节避开全部数据字节
 *
 * dec(encKey): 解密: 由头字节与 '@' 反推随机数, 再逐个 word 反推原文;
 *              含位置校验与值域校验, 篡改/非法输入返回 null
 */
const crypto = require('crypto');

// 加盐(仅服务器端, 不可泄露)
const SALT = 'ng~te#2026$kx';

/** userid -> 确定性密匙(32 hex 字符, 即用户目录名) */
function key(userid) {
    return crypto.createHash('sha256')
        .update(SALT + '\x00' + String(userid))
        .digest('hex').slice(0, 32);
}

/** 加密: 返回 hex 字符串; 非法输入返回 null */
function enc(rawKey) {
    let plain;
    try { plain = Buffer.from(String(rawKey), 'utf8'); } catch (e) { return null; }
    if (!plain.length || plain.length > 64) return null;

    for (let retry = 0; retry < 8; retry++) {
        const rand = 1 + Math.floor(Math.random() * 255);
        const head = 0x40 ^ rand;                       // '@' 与随机字节运算
        const out = Buffer.alloc(1 + plain.length * 2);
        out[0] = head;
        let prev = head & 0x3FF;
        let clash = false;
        for (let j = 0; j < plain.length; j++) {
            const c = plain[j] ^ rand;                  // 与随机数运算
            const mix = (c + prev + j) & 0x3FF;         // 与前一个输出运算(链式)
            const w = (mix << 6) | (j & 0x3F);          // 低 6 位编码位置
            const hi = (w >> 8) & 0xFF, lo = w & 0xFF;
            if (hi === head || lo === head) { clash = true; break; }   // 头字节避开数据字节
            out[1 + j * 2] = hi;
            out[2 + j * 2] = lo;
            prev = w & 0x3FF;
        }
        if (!clash) return out.toString('hex');
    }
    return null;                                        // 理论不可达
}

/** 解密: 返回原文; 非法/篡改输入返回 null */
function dec(encKey) {
    let buf;
    try { buf = Buffer.from(String(encKey), 'hex'); } catch (e) { return null; }
    if (!buf || buf.length < 3 || (buf.length - 1) % 2) return null;

    const rand = buf[0] ^ 0x40;                         // 由 '@' 反推随机数
    if (rand < 1) return null;
    let prev = buf[0] & 0x3FF;
    const out = Buffer.alloc((buf.length - 1) / 2);
    for (let j = 0; j < out.length; j++) {
        const w = (buf[1 + j * 2] << 8) | buf[2 + j * 2];
        if ((w & 0x3F) !== (j & 0x3F)) return null;     // 位置编码校验
        const c = ((w >> 6) - prev - j) & 0x3FF;
        if (c > 0xFF) return null;                      // 值域校验(明文字节经 rand 异或后必 <= 0xFF)
        out[j] = c ^ rand;
        prev = w & 0x3FF;
    }
    return out.toString('utf8');
}

module.exports = { key, enc, dec };