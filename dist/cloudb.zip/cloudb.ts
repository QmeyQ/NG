/**
 * cloudb.ts - CloudDB 存储云函数(源码参考, 部署用编译产物 cloudb.js)
 *
 * 请求: { action: "get"|"put"|"del"|"list", extraData: {...} }
 * 数据行: NG 对象类型结构化字段(id 主键, name, flag, bag JSON, dollar, head, etc=ctime...)
 */
const CloudDBZoneWrapper = require("./CloudDBZoneWrapper.js");
const FIELDS: string[] = CloudDBZoneWrapper.FIELDS;

let myHandler = async function (event: any, context: any, callback: any, logger: any) {
  var action: string;
  var data: any;

  try {
    if (event.body) {
      var _body = JSON.parse(typeof event.body === 'string' ? event.body : JSON.stringify(event.body));
      action = _body.action;
      data = _body.extraData;
    } else {
      action = event.action;
      data = event.extraData;
    }
  } catch (e) {
    callback({ code: 5, msg: '请求解析失败' });
    return;
  }
  if (logger) logger.info("cloudb action: " + action + " id: " + (data && data.id) + " zone: " + (data && data.zone));

  // 存储区: 请求参数 zone 覆盖(缺省 DEFAULT_ZONE, 即环境变量 CLOUDDB_ZONE 或 "User")
  const w = new CloudDBZoneWrapper(logger, data && data.zone);
  try {
    switch (action) {
      case 'get': {
        if (!data || !data.id) { callback({ code: 5, msg: '缺少 id' }); return; }
        const row = await w.executeQueryById(data.id);
        callback({ code: 0, row });
        return;
      }
      case 'put': {
        if (!data || !data.id) { callback({ code: 5, msg: '缺少 id' }); return; }
        // 部分字段更新: 读旧行合并(缺省保留旧值), 整行 upsert
        const merged = await w.executeQueryById(data.id) || {};
        for (const f of FIELDS) {
          if (data[f] !== undefined && data[f] !== null) merged[f] = data[f];
        }
        merged.id = data.id;
        const n = await w.executeUpsert(merged);
        callback({ code: 0, n });
        return;
      }
      case 'del': {
        if (!data || !data.id) { callback({ code: 5, msg: '缺少 id' }); return; }
        const dn = await w.executeDelete(data.id);
        callback({ code: 0, n: dn });
        return;
      }
      case 'list': {
        const rows = await w.executeQueryAll();
        callback({ code: 0, rows });
        return;
      }
      default:
        callback({ code: 5, msg: 'invalid action: ' + action });
    }
  } catch (e: any) {
    if (logger) logger.info("cloudb error: " + (e && e.stack));
    callback({ code: 5, msg: '服务器错误: ' + (e && e.message) });
  }
};

export { myHandler };